# faq-chatbot

FAQ Chatbot is a machine learning based chatbot trained on FAQ [dataset](https://www.kaggle.com/abbbhishekkk/faq-datasets-for-chatbot-training?select=HDFC_Faq.txt) of HDFC Bank.

- Libraries used:
  - Scikit-Learn
  - NLTK
  - Re
  - Numpy
  - Pandas
  - NLPAug

- Results:
![](https://github.com/Aaryanverma/faq-chatbot/blob/main/Screenshot%202021-11-19%20011309.png)
